package cn.sharesdk.onekeyshare;

public enum OnekeyShareTheme {CLASSIC, SKYBLUE}
